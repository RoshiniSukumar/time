const express = require('express')
const mongoose = require("mongoose")
const cors = require("cors")
const app = express()
const port = 2000


app.use(express.json())
app.use(cors())

const teacherss = require("./teachers/Routteacher")
const classs = require("./classs/Routclasss")

app.use("/teacher", teacherss)
app.use("/class", classs)
mongoose.connect("mongodb://localhost:27017/timetable", (err) => {
    if (err) { console.log("error") } else { console.log("connect") }
})



app.get('/', (req, res) => res.send('Hello World!'))
app.listen(port, () => console.log(`Example app listening on port ${port}!`))