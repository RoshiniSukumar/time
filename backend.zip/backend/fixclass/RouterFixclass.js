const express = require("express")
const router = express.Router()
const fixClass = require("./schFixClass")

router.get("/", async(req, res) => {
    const val = await fixClass.find()
    res.status(200).json(val)
})

router.post("/", async(req, res) => {
    console.log(`req.body`, req.body);
    const fixClasspost = await new fixClass({
        sub: req.body.sub
    })
    const fixClasssave = await fixClasspost.save()
    res.status(200).json(fixClasssave)
})




router.put("/", async(req, res) => {
    console.log('i am in put items')
    console.log("data", req.body)
    const updatefixClass = await fixClass.updateMany({ _id: req.body._id }, { $set: { sub: req.body.sub } })

    res.status(200).json(updatefixClass)
})

module.exports = router