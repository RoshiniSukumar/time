const mongoose = require("mongoose")

var fixClass = mongoose.Schema({
    sub: {
        type: Object,
        required: true
    }
})

module.exports = mongoose.model("fixClass", fixClass)